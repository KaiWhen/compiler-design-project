Group 28 - Kevin Wang, Jiss Joseph

To compile, run `make`
To test the program with a test file, run `./ToY <filepath>`